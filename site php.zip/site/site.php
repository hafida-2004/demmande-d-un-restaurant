<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="site.css">
    <title>Document</title>
</head>
<body>
    <header>
        <span class="logo">
            <img src="images/school.png">
        </span>
        <nav class="navigation">
            <a href="#">Accueil</a>
            <a href="#">Services</a>
            <button class="btnLogin" onclick="window.location.href='login.php';"> Login </button>
        </nav>
    </header>
    <div>
        
    </div>
</body>
</html>